# FloppyOctoTouch

A touch-first dashboard for [OctoPrint](https://octoprint.org/), designed for a Raspberry Pi 4 running
OctoPi with a 7" 1024×600 HDMI touch screen, shown full screen in a Chromium kiosk.

> **Status: early development (v0.8.0).** Development environment, local agent, data layer, design system, app
> shell and every screen are in place: Home (print control, live tuning, webcam, screensaver, print notices),
> Files (local storage, SD card, USB stick, slicer thumbnails), Temperature, Move, Filament, Terminal with
> macros, Leveling and System with the settings; the installer for the Pi is next. The screens are being built
> session by session, see [`docs/PLAN.md`](docs/PLAN.md) (Italian) and [`CHANGELOG.md`](CHANGELOG.md).

![Home screen at 1024×600 while printing](docs/images/home-v0.4.0.png)

![Files screen with slicer thumbnails](docs/images/files-v0.5.0.png)

![Temperature screen with the live chart](docs/images/temperature-v0.6.0.png)

![Leveling screen with the bed mesh heatmap](docs/images/leveling-v0.7.0.png)

![System screen with the Raspberry Pi metrics](docs/images/system-v0.8.0.png)

## Features

Available now:

- Home screen with ring gauges (hotend, bed, fan, job, layer with DisplayLayerProgress), progress, times and ETA,
  pause/resume/stop with confirmation, live speed (M220), flow (M221) and fan (M106/M107) sliders, the file
  thumbnail or the webcam; when idle, the recent files ready to print, preheat presets, cooldown and homing.
- Files: OctoPrint local storage with folders, sorting, grid/list views and search with the on-screen keyboard;
  file details (time, filament, dimensions) with print/select/delete; the printer SD card; a USB stick plugged
  into the Pi, whose G-code files are imported into OctoPrint with a progress bar, then ejected safely.
- Slicer thumbnails (PrusaSlicer/OrcaSlicer PNG, JPG and QOI) extracted by the agent, no OctoPrint plugin needed
  (the Slicer Thumbnails plugin is used when installed).
- Screensaver with a large progress/clock view (optionally with the file thumbnail) and optional HDMI power-off
  when idle (never while printing); the touch that wakes the screen never presses a button.
- Temperatures: NumPad targets, per-heater and global off, a live chart (5/15/30 min) and preheat presets you
  can add, edit, reorder and reset.
- Movement: X/Y/Z jog with 0.1/1/10/50 mm steps kept inside the printer profile's build volume, homing, motors
  off, head position, jog speeds.
- Filament: load/unload wizard (heat, insert, load, purge) using M701/M702 or configurable G-code sequences for
  direct or bowden extruders, M600 filament change, manual extrude/retract with cold extrusion protection.
- Terminal: live serial log with filters (temperatures, `ok`, busy, SD status, position), pause and auto-scroll,
  commands typed on an in-app G-code keyboard, history and quick commands; macros as big buttons you can add,
  edit, reorder and reset, with optional confirmation.
- Leveling: paper test at the four corners and the centre (no probe needed), bed mesh heatmap from `M420 V`
  (Marlin bilinear and mesh bed leveling), guided manual mesh (`G29 S1/S2`) or automatic `G29` when the firmware
  has them, babystepping (`M290`, also while printing), probe Z offset (`M851`), save to EEPROM (`M500`).
- System: CPU (with temperature and frequency), RAM and disk rings, network (IP, Wi-Fi name and signal,
  gateway), OctoPrint restart, Pi reboot/shutdown and custom system commands with confirmation, screen restart.
- Power and lights: PSU Control switch (also in the status bar) and custom action buttons that send G-code, run
  an OctoPrint system command or call a plugin API, up to three of them in the status bar.
- Settings on the screen: language, accent colour, clock, end-of-print beep, screensaver and screen off,
  temperature thresholds and limits, jog speeds, paper test, extruder, firmware capability overrides, webcam
  URL, OctoPrint API key (checked by the agent, also from the "connecting" overlay), reset.
- Big end-of-print / failure / pause notices, with the `M300` beep through the printer's buzzer.
- Marlin host prompts (`M876`) shown as touch dialogs.
- English and Italian, fully offline (no CDN, works without Wi-Fi).

Planned:

- Installer for OctoPi (kiosk, services, USB automount), then a test on the real hardware.

## How it works

```
Chromium (kiosk) ──► agent 127.0.0.1:8765 ──► OctoPrint 127.0.0.1:5000
                      • serves the web app
                      • proxies /api, /sockjs, /plugin, /downloads and adds the API key
                      • proxies /webcam/* to camera-streamer (127.0.0.1:8080), like OctoPi's haproxy
                      • local endpoints: /local/health, /local/settings, /local/system (CPU, RAM, disk,
                        network), /local/apikey, /local/kiosk/restart, /local/display (HDMI on/off),
                        /local/thumbnail (G-code thumbnails), /local/usb (USB stick), /local/events, …
```

The browser never sees the OctoPrint API key: the Python agent injects it. For this reason the agent listens on
`127.0.0.1` only. Details in [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

- **Frontend**: Svelte 5 + TypeScript + Vite (`frontend/`).
- **Agent**: Python 3.11 + aiohttp (`agent/`).

## Development

Everything runs in Docker: nothing (Node, Python, Playwright…) needs to be installed on the host.
Requirements: Docker with Compose v2 (Docker Desktop on Windows/macOS works).

```sh
# optional: copy and adjust ports / credentials
cp dev/.env.example dev/.env

docker compose -f dev/docker-compose.yml up -d
```

| URL | What |
|---|---|
| http://localhost:5173/preview.html | the dashboard inside a 1024×600 frame (Vite dev server, hot reload) |
| http://localhost:5173/ | the dashboard without frame |
| http://localhost:8765/ | the agent (serves `frontend/dist` once built, same as on the Pi) |
| http://localhost:5000/ | OctoPrint with the Virtual Printer (user `admin`, password `admin`) |

The development OctoPrint is prepared automatically on first start (`octoprint-init` service): seed config
(Virtual Printer with SD card, auto-connect, 220×220×240 printer profile), admin user, sample G-code files
(plus an `examples/` folder and one file on the virtual SD card).
To start from scratch: `docker compose -f dev/docker-compose.yml down -v`.

The `webcam` service is a fake camera: an MJPEG test pattern with a frame counter (ffmpeg `testsrc`) on port 8080,
like camera-streamer on OctoPi. OctoPrint's default stream URL `/webcam/?action=stream` reaches it through the
agent. Stop it (`docker compose -f dev/docker-compose.yml stop webcam`) to see the "no webcam" fallback. In Docker
the HDMI power endpoint (`/local/display`) only logs (`FOT_DISPLAY_BACKEND=none`).

`dev/fake-usb/` is the fake USB stick (`/media/usb0` in the agent, read-only): drop `.gcode` files there and tap
refresh on the USB tab. The agent notices a stick appearing or disappearing within 2 s. There is no udev/systemd
in Docker, so "Eject" only hides the stick until its content changes (`FOT_USB_EJECT_COMMAND=none`). The agent
reads OctoPrint's uploads (volume mounted read-only) to extract thumbnails, as it does on the Pi.

Agent settings added for files and the System screen (in `config.json` or as `FOT_*` environment variables):

| Setting | Default | What |
|---|---|---|
| `uploads_dir` (`FOT_UPLOADS_DIR`) | `~/.octoprint/uploads` | OctoPrint's local storage, read for thumbnails (download through OctoPrint if not readable) |
| `usb_roots` (`FOT_USB_ROOTS`) | `/media/usb*` | glob patterns of the USB stick mount points |
| `usb_eject_command` (`FOT_USB_EJECT_COMMAND`) | `systemd-mount --umount {path}` | command that unmounts a stick; `none` only hides it |
| `usb_max_file_mb` (`FOT_USB_MAX_FILE_MB`) | `1024` | largest file accepted for import |
| `kiosk_restart_command` (`FOT_KIOSK_RESTART_COMMAND`) | `sudo -n systemctl restart floppyoctotouch-kiosk.service` | "Restart the screen" on the System screen; `none` only logs (the page reloads) |
| `disk_path` (`FOT_DISK_PATH`) | `/` | file system shown as "disk" on the System screen |

Pages and URL options useful while developing:

| URL | What |
|---|---|
| `/#/home`, `/#/files`, … `/#/system` | a screen of the app (the hash keeps the current screen across reloads) |
| `/ui-gallery` | every design-system component with demo data (dev server only) |
| `/debug` | every data store: connection, printer state, job, temperatures, files, capabilities, plugins, prompts, settings, events, terminal (dev server only) |
| `?accent=teal\|amber\|indigo` | previews an accent colour (the saved one is chosen on the System screen) |
| `?kiosk=1` | kiosk hardening: hidden cursor, no context menu, no zoom, no text selection or dragging |

In the Vite dev server the stores are also available in the browser console as `window.__fot`.

The Virtual Printer can emit Marlin host actions to test prompts and notifications, e.g. send
`!!DEBUG:action_custom notification Hello` from the OctoPrint terminal (the `/debug` page has buttons for this).
Prompts are shown only when the firmware reports `Cap:PROMPT_SUPPORT` (or the override is on).

### OctoPrint API key

The agent authenticates to OctoPrint with an API key taken from `OCTOPRINT_API_KEY` in `dev/.env`.
In development you do not need to create it: `octoprint-init` registers that value as an application key of the
dev user at every start (a default value is used when `dev/.env` does not exist).

To use a key created by hand (as you will do on the Pi):

1. open OctoPrint at http://localhost:5000 and log in;
2. go to **Settings → Application Keys**, enter an application name (e.g. `FloppyOctoTouch`) and click **Generate**;
3. put the key in `dev/.env` as `OCTOPRINT_API_KEY=...` and restart: `docker compose -f dev/docker-compose.yml up -d`.

`http://localhost:8765/local/health` tells whether OctoPrint is reachable and the key is accepted.

The key can also be replaced from the dashboard (System → Settings → Connection, or the button on the
"connecting" overlay when OctoPrint rejects it): the agent checks it against OctoPrint, saves it in its
`config.json` (mode 600) and uses it at once. A key set through `FOT_API_KEY` (as in Docker) wins again at the
next start.

The development OctoPrint has harmless reboot/shutdown commands (`echo`) and a custom `Toggle lights (dev)`
system command, so the System screen shows them; the smoke test intercepts reboot/shutdown anyway.

### Recurring commands

All commands are run from the repository root.

| Command | What |
|---|---|
| `docker compose -f dev/docker-compose.yml up -d` | start OctoPrint, agent and Vite |
| `docker compose -f dev/docker-compose.yml logs -f agent` | follow the agent logs (same for `octoprint`, `frontend`) |
| `docker compose -f dev/docker-compose.yml down` | stop everything (`-v` also wipes OctoPrint data) |
| `docker compose -f dev/docker-compose.yml run --rm agent-test` | agent: ruff lint + format check + pytest |
| `docker compose -f dev/docker-compose.yml run --rm frontend-test` | frontend: svelte-check + tsc + vitest |
| `docker compose -f dev/docker-compose.yml run --rm build` | production build of the frontend into `frontend/dist` |
| `docker compose -f dev/docker-compose.yml run --rm playwright` | smoke test (data layer, every screen, NumPad and confirmations, host prompt, printer overlay, Files (folders, sort, search, detail, delete, SD card, USB import/eject), Temperature (targets, presets CRUD), Move (jog limits), Filament (setup, load/unload wizard, manual extrusion), Terminal (keyboard, filters, pause, history), macros CRUD, Leveling (paper test, mesh heatmap, manual mesh, babystep, probe offset), System (metrics, system commands, custom actions and status bar, every settings section, API key, reset, PSU Control), a real print from the Home with fan/speed sliders, pause/resume, webcam and the end-of-print notice, screensaver and screen off, kiosk mode, language) + 1024×600 screenshots into `dev/screenshots/`; `-e ONLY=terminal,leveling` runs only those steps |
| `docker compose -f dev/docker-compose.yml run --rm playwright sh -c "npm install && node accents.mjs"` | screenshots of Home, NumPad and gallery for each accent colour |
| `docker compose -f dev/docker-compose.yml run --rm shellcheck` | lint every shell script |

Sample G-code files with PrusaSlicer (PNG, QOI) and OrcaSlicer thumbnails live in `dev/sample-gcode/` and are
generated by `dev/tools/make_sample_gcode.py`; `3dbenchy_prusaslicer.gcode` is a real PrusaSlicer 2.9 export for
the Tatara A8 profile (240 layers, about 45 min, 300×300 PNG thumbnail), handy for long jobs and real file info.
`dev/fake-usb/` is mounted into the agent as a fake USB stick.

## Installation on the Raspberry Pi

Not available yet: an `install.sh` for OctoPi 1.1.0 (Bookworm) is planned (kiosk with `cage` + Chromium,
systemd services, USB automount).

## Project layout

```
agent/      Python agent (aiohttp): static files, OctoPrint proxy, local endpoints
frontend/   Svelte 5 + TypeScript web app
deploy/     install/update/uninstall scripts, systemd units, kiosk launcher (to come)
dev/        Docker Compose environment, OctoPrint seed, Playwright scripts, sample G-code
docs/       plan (Italian) and architecture notes
scripts/    release tooling (to come)
```

## License

[MIT](LICENSE) © 2026 Filippo Castellan
